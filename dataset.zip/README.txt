OVERVIEW

This dataset represents raw input electroencephalograhy (EEG) data recorded using the Emotiv EPOC Wireless EEG device 
and the corresponding output vectors in the context of motor imagery tasks performed by a healthy participant. 

Informed consent was obtained from the participant and the studies were approved by the Health Research Ethics Committee
of the Institute of Biomedical Research at the University of Uyo.

One electrode or channel was used in the studies and it was placed above the motor cortex within the frontal lobe of the 
left hemisphere of the brain.

Three motor imagery tasks were performed by the participant, namely, Left Fist Closed, Right Fist Closed and Neutral (both
fists open).

Essentially, three output classes or categories (Left Fist Closed, Right Fist Closed, Neutral) of motor imagery activity 
were delineated.


DATA STRUCTURE

The dataset comprises rows of numbers in comma separated values (CSV) format.
Each row starts with 128 numbers representing one second of input raw EEG data (the numbers represent the voltage in microvolts) 
measured on the scalp at the electrode used (the sampling rate was 128 samples per second) followed by the 
corresponding 3-element output vector representing the corresponding class or category in one-hot encoding. 

The encodings used in the 3-element output vectors and their correponding motor imagery activities are as follows:

Left Fist Closed:	1	0	0
Neutral:		0	1	0
Right Fist Closed:	0	0	1  

